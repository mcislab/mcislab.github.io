Bram Adams BC3
bram.adams@pro.tiscali.be
-----------------------------------------------------------------------------
-APPENDIX bij "Aspectgenerator voor declaratieve definitie van persistentie"-
-----------------------------------------------------------------------------


*****************
*dependencies*
*****************
*myHibernate.jar:
= Hibernate 2.0.3, gebruikt voor mapping op databankdatatypes (daar zijn enkele wijzigingen gebeurd in net.sf.hibernate.sql.Create/Drop/Update en net.sf.util.StringHelper
->benodigde libraries:
	*commons-collections.jar
	*commons-lang.jar	
	*commons-logging.jar
	*myHibernate.jar
*myJDO.jar:
= FOStore met wijzigingen om queries op @persistent-klassen en -interfaces toe te laten. com.sun.jdori.common.query.MyMemoryQuery en -MyQueryImpl werden gecreëerd(zie subsectie 6.3.5 van eindwerk), com.sun.jdori.common.query.BasicQueryResult/QueryResultHelperImpl werden gewijzigd (persistence manager weghalen).
->benodigde libraries:
	*btree.jar
	*jta.jar
	*myAntlr.jar (zelf gecompileerd, vandaar "my")
	*myJDO.jar
*mysql-connector-java-3.0.10-stable-bin.jar (niet in zip): mySQL-databank
*junit.jar(niet in zip): tests
*EMF-plugin van http://www.eclipse.org/emf/ voor JET: enkel als inhoud templates-directory veranderd zou worden

***********
*werking*
***********
1) generatie persistentiebestanden uit PDL-tags:
doc.xml als Ant build file uitvoeren
2) generatie introducer-aspect:
PersistenceIntroducerGenerator met als argumenten: introducer.xsl xml/classfile.xml aspects/PersistenceIntroducer.java
3) generatie implementor-aspecten:
PersistenceImplementorGenerator met als argumenten: implementor.xsl xml/classfile.xml xml aspects/imp
4) kies als injar (rechtsklik->Properties->AspectJ Compiler): myJDO.jar en kies een naam voor output jar
5) build (an weave)
6) in db.properties de juiste gegevens voor databank opgeven (de juiste Hibernate-entry kan opgezocht worden in myHibernate.jar en dient om juiste SQL-dialect op te geven)
-> de databank moet bestaan, maar de tabellen NIET
7) Script uitvoeren (geen argumenten) om tabellen in databank te creëren.
8) in ander project (ook AspectJ-enabled!) de output jar in het path steken

